function convertPDF() {
  const fileInput = document.getElementById('pdfFile');
  if (fileInput.files.length === 0) {
    alert('Please select a PDF file!');
    return;
  }

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append('file', file);

  fetch('https://api.yourserver.com/pdf-to-word', {
    method: 'POST',
    body: formData
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Conversion failed!');
    }
    return response.blob();
  })
  .then(blob => {
    const downloadUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = 'converted.docx';
    link.textContent = 'Download Word File';
    document.getElementById('downloadLink').innerHTML = '';
    document.getElementById('downloadLink').appendChild(link);
  })
  .catch(err => {
    console.error('Conversion error:', err);
    alert('Something went wrong during conversion.');
  });
}